package com.portum.opengl.sdk.sample;

/**
 * Created by User on 2016/8/14.
 */

public interface SetValueChanged {
    public void setValue(float x, float y, float z);
}
